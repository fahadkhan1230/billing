import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
export default function Home(){return <><SiteHeader/><main className="welcome home-welcome"><p className="eyebrow">WELCOME TO</p><h1>UCCHASH CENTER <em>BILLING SYSTEM</em></h1><p>ধাপে ধাপে তথ্য পূরণ করুন। প্রতিটি ধাপ আলাদা পেজে খুলবে এবং তথ্য স্বয়ংক্রিয়ভাবে সংরক্ষিত থাকবে।</p><Link className="primary big" href="/billing/step-1">শুরু করুন →</Link></main><SiteFooter/></>}
